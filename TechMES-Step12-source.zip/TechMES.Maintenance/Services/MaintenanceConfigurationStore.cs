using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization.Metadata;
using TechMES.Maintenance.Models;

namespace TechMES.Maintenance.Services;

/// <summary>
/// Загружает настройки обслуживающего приложения.
/// Локальный профиль разработки хранится рядом с шаблоном настроек.
/// </summary>
public sealed class MaintenanceConfigurationStore(DirectoryInfo repositoryRoot)
{
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true,

        // maintenance.settings.json часто редактируется вручную.
        // Разрешаем JSONC-комментарии и trailing comma, чтобы временно отключать строки через // без сброса на дефолт.
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        TypeInfoResolver = new DefaultJsonTypeInfoResolver()
    };

    /// <summary>
    /// Возвращает путь профиля для компьютера разработки или сервера.
    /// Серверный профиль сохраняется независимо от обновлений Maintenance.
    /// </summary>
    public string ConfigurationPath =>
        File.Exists(Path.Combine(repositoryRoot.FullName, "TechMES.sln"))
            ? Path.Combine(repositoryRoot.FullName, "TechMES.Maintenance", "maintenance.settings.local.json")
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "TechMES", "Maintenance", "maintenance.settings.json");

    /// <summary>
    /// Читает конфигурацию Maintenance.
    /// Если файл отсутствует или JSON поврежден, возвращает дефолтную конфигурацию и не ломает запуск UI.
    /// </summary>
    public MaintenanceConfiguration Load()
    {
        var path = ConfigurationPath;
        if (!File.Exists(path) && File.Exists(Path.Combine(repositoryRoot.FullName, "TechMES.sln")))
            path = Path.Combine(repositoryRoot.FullName, "TechMES.Maintenance", "maintenance.settings.json");

        if (!File.Exists(path))
            return MaintenanceConfiguration.CreateDefault();

        try
        {
            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<MaintenanceConfiguration>(json, _jsonOptions)
                ?? MaintenanceConfiguration.CreateDefault();
        }
        catch
        {
            return MaintenanceConfiguration.CreateDefault();
        }
    }

    /// <summary>
    /// Сохраняет профиль и создаёт его каталог при первом запуске.
    /// </summary>
    public void Save(MaintenanceConfiguration configuration)
    {
        var json = JsonSerializer.Serialize(configuration, _jsonOptions);
        Directory.CreateDirectory(Path.GetDirectoryName(ConfigurationPath)!);
        File.WriteAllText(ConfigurationPath, json);

    }
}
