﻿using System.Collections.Concurrent;
using TechMES.Application.Scada;
using TechMES.Contracts.Scada;

namespace TechMES.Infrastructure.CtApi.Gateways;

/// <summary>
/// Mock adapter Plant SCADA.
/// 
/// Он нужен для безопасной разработки WEB/Runtime API без реального CtApi.
/// Значения tag-ов хранятся в памяти процесса.
/// Позже этот adapter заменим на CtApiPlantScadaGateway.
/// </summary>
public sealed class MockPlantScadaGateway : IPlantScadaGateway
{
    /// <summary>
    /// In-memory набор tag-ов для разработки без реальной Plant SCADA.
    /// </summary>
    private readonly ConcurrentDictionary<string, string?> _tags =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Заполняет несколько тестовых tag-ов при старте Runtime.Service.
    /// </summary>
    public Task InitializeAsync(CancellationToken ct = default)
    {
        // Несколько тестовых tag-ов, чтобы можно было проверить API.
        _tags.TryAdd("S01.H01.P01.Run", "0");
        _tags.TryAdd("S01.H01.P01.Mode", "Auto");
        _tags.TryAdd("S01.H01.P01.Speed", "1450");
        _tags.TryAdd("S01.H01.LT01.Value", "45.2");

        return Task.CompletedTask;
    }

    /// <summary>
    /// Возвращает health-ответ Mock provider-а.
    /// </summary>
    public Task<PlantScadaHealthResponse> GetHealthAsync(CancellationToken ct = default)
    {
        return Task.FromResult(new PlantScadaHealthResponse
        {
            Provider = "Mock",
            Status = PlantScadaConnectionStatus.Mock,
            IsConnected = true,
            Message = "Plant SCADA gateway работает в Mock-режиме.",
            Time = DateTime.Now
        });
    }

    /// <summary>
    /// Читает tag из in-memory словаря.
    /// </summary>
    public Task<ScadaTagReadResponse> ReadTagAsync(string tagName, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(tagName))
        {
            return Task.FromResult(new ScadaTagReadResponse
            {
                TagName = tagName,
                Success = false,
                Error = "TagName is required.",
                Time = DateTime.Now
            });
        }

        var normalizedTagName = tagName.Trim();

        _tags.TryGetValue(normalizedTagName, out var value);

        return Task.FromResult(new ScadaTagReadResponse
        {
            TagName = normalizedTagName,
            Value = value ?? "",
            Success = true,
            Time = DateTime.Now
        });
    }

    /// <summary>
    /// Читает набор тегов из in-memory Mock-хранилища.
    /// </summary>
    public Task<ScadaTagBatchReadResponse> ReadTagsAsync(IReadOnlyCollection<string> tagNames, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(tagNames);

        var normalizedNames = ScadaTagBatchHelper.NormalizeTagNames(tagNames);
        var readAtUtc = DateTimeOffset.UtcNow;
        var items = new List<ScadaTagBatchReadItem>(normalizedNames.Count);

        foreach (var tagName in normalizedNames)
        {
            if (_tags.TryGetValue(tagName, out var value))
            {
                items.Add(new ScadaTagBatchReadItem
                {
                    TagName = tagName,
                    Value = value,
                    TimestampUtc = DateTimeOffset.UtcNow,
                    Quality = ScadaTagQuality.Good,
                    Success = true
                });
            }
            else
            {
                items.Add(new ScadaTagBatchReadItem
                {
                    TagName = tagName,
                    TimestampUtc = DateTimeOffset.UtcNow,
                    Quality = ScadaTagQuality.Bad,
                    Success = false,
                    Error = "Mock SCADA tag was not found."
                });
            }
        }

        return Task.FromResult(new ScadaTagBatchReadResponse
        {
            ReadAtUtc = readAtUtc,
            RequestedCount = tagNames.Count,
            UniqueCount = normalizedNames.Count,
            SuccessCount = items.Count(item => item.Success),
            FailureCount = items.Count(item => !item.Success),
            Items = items
        });
    }

    /// <summary>
    /// Записывает tag в in-memory словарь.
    /// </summary>
    public Task<ScadaTagWriteResponse> WriteTagAsync(ScadaTagWriteRequest request, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(request.TagName))
        {
            return Task.FromResult(new ScadaTagWriteResponse
            {
                TagName = request.TagName,
                WrittenValue = request.Value,
                Success = false,
                Error = "TagName is required.",
                Time = DateTime.Now
            });
        }

        var normalizedTagName = request.TagName.Trim();

        _tags[normalizedTagName] = request.Value;

        return Task.FromResult(new ScadaTagWriteResponse
        {
            TagName = normalizedTagName,
            WrittenValue = request.Value,
            Success = true,
            Time = DateTime.Now
        });
    }
}
