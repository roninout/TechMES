﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using TechMES.Application.Scada;
using TechMES.Contracts.Scada;
using TechMES.Infrastructure.CtApi.Native;
using TechMES.Infrastructure.CtApi.Settings;

namespace TechMES.Infrastructure.CtApi.Gateways;

/// <summary>
/// Реальный Plant SCADA gateway через CtApi.
///
/// Этот класс уже является полноценным adapter-слоем Runtime.Service.
/// Он:
/// - открывает CtApi при старте;
/// - сериализует все CtApi-вызовы через SemaphoreSlim;
/// - безопасно возвращает ошибки в API;
/// - запрещает запись, если AllowWrites=false;
/// - хранит состояние подключения.
/// </summary>
public sealed class CtApiPlantScadaGateway : IPlantScadaGateway, IPlantScadaHealthMonitor, IAsyncDisposable
{
    /// <summary>
    /// Низкоуровневый wrapper над CtApi.dll. Gateway не вызывает legacy-код напрямую.
    /// </summary>
    private readonly ICtApiNativeClient _nativeClient;

    /// <summary>
    /// Текущие настройки CtApi из appsettings Runtime.Service.
    /// </summary>
    private readonly IOptions<CtApiOptions> _options;

    /// <summary>
    /// Логгер для диагностики подключения, чтения и записи tag-ов.
    /// </summary>
    private readonly ILogger<CtApiPlantScadaGateway> _logger;

    /// <summary>
    /// CtApi не должен вызываться параллельно из разных HTTP-запросов.
    /// Поэтому все вызовы TagRead/TagWrite/Open идут через один gate.
    /// </summary>
    private readonly SemaphoreSlim _apiGate = new(1, 1);

    /// <summary>
    /// Последний известный статус соединения, который отдается endpoint-у диагностики.
    /// </summary>
    private PlantScadaConnectionStatus _status = PlantScadaConnectionStatus.Disconnected;

    /// <summary>
    /// Человекочитаемое описание последнего состояния или ошибки соединения.
    /// </summary>
    private string _lastMessage = "CtApi adapter ещё не инициализирован.";

    /// <summary>
    /// Момент последнего изменения состояния. Пока используется как внутренняя диагностика.
    /// </summary>
    private DateTime _lastStateChangedAt = DateTime.Now;

    /// <summary>
    /// Создает Plant SCADA gateway поверх низкоуровневого CtApi native-клиента.
    /// </summary>
    public CtApiPlantScadaGateway(ICtApiNativeClient nativeClient, IOptions<CtApiOptions> options, ILogger<CtApiPlantScadaGateway> logger)
    {
        _nativeClient = nativeClient;
        _options = options;
        _logger = logger;
    }

    /// <summary>
    /// Открывает CtApi при старте Runtime.Service. Ошибка не валит сервис, а переводит gateway в Disconnected.
    /// </summary>
    public async Task InitializeAsync(CancellationToken ct = default)
    {
        await _apiGate.WaitAsync(ct);

        try
        {
            SetState(PlantScadaConnectionStatus.Connecting, "Открываем CtApi connection...");

            await _nativeClient.OpenAsync(ct);

            if (!await _nativeClient.TryProbeConnectionAsync(ct))
                throw new InvalidOperationException("CtApi health probe failed.");

            SetState(PlantScadaConnectionStatus.Connected, "CtApi connection открыт.");
        }
        catch (Exception ex)
        {
            SetState(PlantScadaConnectionStatus.Disconnected, "Ошибка открытия CtApi: " + ex.Message);
            _logger.LogError(ex, "Не удалось открыть CtApi connection.");

            // ВАЖНО:
            // Пока не валим Runtime.Service при ошибке CtApi. WEB должен запуститься и показать health=Disconnected.
            // Позже можно добавить настройку: CtApi:FailFastOnStartup = true.
        }
        finally
        {
            _apiGate.Release();
        }
    }

    /// <summary>
    /// Возвращает готовый снимок CtApi. Проверку и резервирование запускает health worker.
    /// </summary>
    public Task<PlantScadaHealthResponse> GetHealthAsync(CancellationToken ct = default)
    {
        var redundancy = (_nativeClient as CtApiFailoverClient)?.State;
        var connected = redundancy is null ? _status == PlantScadaConnectionStatus.Connected : redundancy.ActiveRole is not null;

        return Task.FromResult(new PlantScadaHealthResponse
        {
            Provider = "CtApi",
            IsConnected = connected,
            Status = connected ? PlantScadaConnectionStatus.Connected : PlantScadaConnectionStatus.Disconnected,
            Message = redundancy is null ? _lastMessage : connected ? $"Connected to {redundancy.ActiveRole}: {redundancy.ActiveServer}." : "Neither CtApi server is connected.",
            Redundancy = redundancy,
            Time = DateTime.Now
        });
    }

    public async Task RefreshHealthAsync(CancellationToken ct = default)
    {
        // Проверки серверов имеют собственные gate и не занимают общую очередь TagRead/TagWrite.
        if (_nativeClient is CtApiFailoverClient redundant)
        {
            await redundant.RefreshAsync(true, ct);
            SetState(redundant.State.ActiveRole is null ? PlantScadaConnectionStatus.Disconnected : PlantScadaConnectionStatus.Connected, "CtApi health cycle completed.");
            return;
        }

        await _apiGate.WaitAsync(ct);

        try
        {
            if (!await _nativeClient.TryProbeConnectionAsync(ct))
            {
                await _nativeClient.CloseAsync(ct);
                await _nativeClient.OpenAsync(ct);
            }

            SetState(await _nativeClient.TryProbeConnectionAsync(ct) ? PlantScadaConnectionStatus.Connected : PlantScadaConnectionStatus.Disconnected, "CtApi health cycle completed.");
        }
        finally
        {
            _apiGate.Release();
        }
    }

    private bool IsConnected => _nativeClient is CtApiFailoverClient redundant ? redundant.State.ActiveRole is not null : _status == PlantScadaConnectionStatus.Connected;

    /// <summary>Читает один тег и освобождает общий gate при любом результате.</summary>
    public async Task<ScadaTagReadResponse> ReadTagAsync(string tagName, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(tagName))
        {
            return new ScadaTagReadResponse
            {
                TagName = tagName,
                Success = false,
                Error = "TagName is required.",
                Time = DateTime.Now
            };
        }

        if (!IsConnected)
        {
            return new ScadaTagReadResponse
            {
                TagName = tagName,
                Success = false,
                Error = "CtApi is not connected. " + _lastMessage,
                Time = DateTime.Now
            };
        }

        await _apiGate.WaitAsync(ct);

        try
        {
            var normalizedTagName = tagName.Trim();
            var value = await _nativeClient.TagReadAsync(normalizedTagName, ct);

            return new ScadaTagReadResponse
            {
                TagName = normalizedTagName,
                Value = value,
                Success = true,
                Time = DateTime.Now
            };
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error TagRead. Tag={TagName}", tagName);

            // Ошибка отдельного тега не означает потерю соединения.
            return new ScadaTagReadResponse
            {
                TagName = tagName,
                Success = false,
                Error = ex.Message,
                Time = DateTime.Now
            };
        }
        finally
        {
            // Без Release последующие чтения и записи останутся ждать этот gate.
            _apiGate.Release();
        }
    }

    /// <summary>
    /// Пакетно читает набор SCADA-тегов.
    ///
    /// Общий CtApi gate захватывается один раз на весь запрос.
    /// Теги читаются последовательно, потому что CtApi нельзя безопасно
    /// вызывать параллельно из нескольких потоков.
    /// </summary>
    public async Task<ScadaTagBatchReadResponse> ReadTagsAsync(IReadOnlyCollection<string> tagNames, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(tagNames);

        var normalizedNames = ScadaTagBatchHelper.NormalizeTagNames(tagNames);
        var readAtUtc = DateTimeOffset.UtcNow;

        if (!IsConnected)
        {
            var disconnectedItems = normalizedNames.Select(tagName => new ScadaTagBatchReadItem
            {
                TagName = tagName,
                TimestampUtc = readAtUtc,
                Quality = ScadaTagQuality.Bad,
                Success = false,
                Error = "CtApi is not connected. " + _lastMessage
            }).ToList();

            return BuildBatchResponse(tagNames.Count, normalizedNames.Count, readAtUtc, disconnectedItems);
        }

        var items = new List<ScadaTagBatchReadItem>(normalizedNames.Count);

        await _apiGate.WaitAsync(ct);

        try
        {
            foreach (var tagName in normalizedNames)
            {
                try
                {
                    var value = await _nativeClient.TagReadAsync(tagName, ct);

                    items.Add(new ScadaTagBatchReadItem
                    {
                        TagName = tagName,
                        Value = value,
                        TimestampUtc = DateTimeOffset.UtcNow,

                        // Текущее CtApi API возвращает значение, но не нативное quality.
                        Quality = ScadaTagQuality.Unknown,
                        Success = true
                    });
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Ошибка batch TagRead. Tag={TagName}", tagName);

                    items.Add(new ScadaTagBatchReadItem
                    {
                        TagName = tagName,
                        TimestampUtc = DateTimeOffset.UtcNow,
                        Quality = ScadaTagQuality.Bad,
                        Success = false,
                        Error = ex.Message
                    });
                }
            }

             // Ошибки отдельных тегов не изменяют состояние CtApi-соединения.
             // Неправильное имя тега не означает потерю связи с сервером.
             //
             // Состояние Connected/Disconnected определяет отдельный health probe.
            return BuildBatchResponse(tagNames.Count, normalizedNames.Count, readAtUtc, items);
        }
        finally
        {
            _apiGate.Release();
        }
    }

    /// <summary>
    /// Формирует сводный ответ пакетного чтения.
    /// </summary>
    private static ScadaTagBatchReadResponse BuildBatchResponse(int requestedCount, int uniqueCount, DateTimeOffset readAtUtc, List<ScadaTagBatchReadItem> items)
    {
        return new ScadaTagBatchReadResponse
        {
            ReadAtUtc = readAtUtc,
            RequestedCount = requestedCount,
            UniqueCount = uniqueCount,
            SuccessCount = items.Count(item => item.Success),
            FailureCount = items.Count(item => !item.Success),
            Items = items
        };
    }

    /// <summary>
    /// Записывает один SCADA tag, если запись разрешена настройкой CtApi:AllowWrites.
    /// </summary>
    public async Task<ScadaTagWriteResponse> WriteTagAsync(ScadaTagWriteRequest request, CancellationToken ct = default)
    {
        var options = _options.Value;

        if (string.IsNullOrWhiteSpace(request.TagName))
        {
            return new ScadaTagWriteResponse
            {
                TagName = request.TagName,
                WrittenValue = request.Value,
                Success = false,
                Error = "TagName is required.",
                Time = DateTime.Now
            };
        }

        if (!options.AllowWrites)
        {
            return new ScadaTagWriteResponse
            {
                TagName = request.TagName,
                WrittenValue = request.Value,
                Success = false,
                Error = "CtApi writes are disabled. Set CtApi:AllowWrites = true to allow writing.",
                Time = DateTime.Now
            };
        }

        if (!IsConnected)
        {
            return new ScadaTagWriteResponse
            {
                TagName = request.TagName,
                WrittenValue = request.Value,
                Success = false,
                Error = "CtApi is not connected. " + _lastMessage,
                Time = DateTime.Now
            };
        }

        await _apiGate.WaitAsync(ct);

        try
        {
            var normalizedTagName = request.TagName.Trim();

            await _nativeClient.TagWriteAsync(
                normalizedTagName,
                request.Value,
                ct);

            return new ScadaTagWriteResponse
            {
                TagName = normalizedTagName,
                WrittenValue = request.Value,
                Success = true,
                Time = DateTime.Now
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка TagWrite. Tag={TagName}, Value={Value}", request.TagName, request.Value);

            SetState(PlantScadaConnectionStatus.Disconnected, "Ошибка TagWrite: " + ex.Message);

            return new ScadaTagWriteResponse
            {
                TagName = request.TagName,
                WrittenValue = request.Value,
                Success = false,
                Error = ex.Message,
                Time = DateTime.Now
            };
        }
        finally
        {
            _apiGate.Release();
        }
    }

    /// <summary>
    /// Закрывает CtApi-соединение при остановке DI-контейнера.
    /// </summary>
    public async ValueTask DisposeAsync()
    {
        await _apiGate.WaitAsync();

        try
        {
            await _nativeClient.CloseAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка закрытия CtApi connection.");
        }
        finally
        {
            _apiGate.Release();
            _apiGate.Dispose();
        }
    }

    /// <summary>
    /// Обновляет локальное состояние gateway, которое затем видит endpoint диагностики.
    /// </summary>
    private void SetState(PlantScadaConnectionStatus status, string message)
    {
        _status = status;
        _lastMessage = message;
        _lastStateChangedAt = DateTime.Now;
    }
}
